# Brewin' And Chewin'

<a href="https://www.curseforge.com/minecraft/mc-mods/brewin-and-chewin">
  <img src="http://cf.way2muchnoise.eu/full_637808_downloads.svg" alt="Curseforge Downloads">
</a>
<a href="https://discord.gg/M5AtJGPf">
  <img alt="Discord" src="https://img.shields.io/discord/855495317298741248?color=brightgreen&label=Discord">
</a>
<br>
<img src="https://i.imgur.com/EFkjwBq.png" width="50%">

### Overview

**Brewin' and Chewin'** is an addon mod for Farmer's Delight.

Using a keg, you can brew or ferment many new foods, including liquors, cheese, and fudge!

### Required Dependencies
- [Farmer's Delight](https://github.com/vectorwing/FarmersDelight/)

### Discord
- [Chef's Delights Discord](https://discord.gg/7PBaMYNtrg) for questions or whatever~
