This is a guide for how to spawn in custom hats and figuring out what codes to use! These hats were made with their respective skin in mind, so they may clip through other skins. They can still be worn on other skins, but they might not look right! You've been warned!


The in-game command to spawn a hat is:

"/give @s minecraft:carved_pumpkin{CustomModelData:X}"

Replace X with one of the numbers below!


~ ~ ~
Gen 1

101: Red - Pokémon FireRed/LeafGreen

1011: Red - (NO HAIR VERSION)

102: Leaf - Pokémon Firered/LeafGreen

1022: Leaf - (NO HAIR VERSION)

103: Blue - Pokémon FireRed/LeafGreen

150: Team Rocket - Pokémon HeartGold/SoulSilver

~ ~ ~
Gen 2

201: Gold - Pokémon Gold/Silver/Crystal

2011: Gold - (NO HAIR VERSION)

202: Kris - Pokémon Crystal

203: Lyra - Pokémon HeartGold/SoulSilver

203: Lyra - (NO HAIR VERSION)

204: Silver - Pokémon HeartGold/SoulSilver

~ ~ ~
Gen 3

301: Brendan - Pokémon Emerald

3011: Brendan - (NO HAIR VERSION)

302: May - Pokémon Ruby/Sapphire

3022: May - (NO HAIR VERSION)

350: Team Aqua - Pokémon Omega Ruby/Alpha Sapphire

351: Team Magma - Pokémon Omega Ruby/Alpha Sapphire

~ ~ ~
Gen 4

401: Lucas - Pokémon Platinum

4011: Lucas - (NO HAIR VERSION)

402: Dawn - Pokémon Diamond/Pearl

4022: Dawn - (NO HAIR VERSION)

403: Barry - Pokémon Diamond/Pearl

450: Team Galactic - Pokémon Diamond/Pearl/Platinum

~ ~ ~
Gen 5

501: Hilbert - Pokémon Black/White

5011: Hilbert - (NO HAIR VERSION)

502: Hilda - Pokémon Black/White

5022: Hilda - (NO HAIR VERSION)

503: Nate - Pokémon Black 2/White 2

5033: Nate - (NO HAIR VERSION)

504: Rosa - Pokémon Black 2/White 2

5044: Rosa - (NO HAIR VERSION)

506: N - Pokémon Black/White

5066: N - (NO HAIR VERSION)

507: Bianca - Pokémon Black 2/White 2

507: Bianca - (NO HAIR VERSION)

550: Team Plasma - Pokémon Black 2/White 2

~ ~ ~
Gen 6

601: Calem - Pokémon X/Y

6011: Calem - (NO HAIR VERSION)

602: Serena - Pokémon X/Y

6022: Serena - (NO HAIR VERSION)

650: Team Flare - Pokémon X/Y

~ ~ ~
Gen 7

701: Elio - Pokémon Ultra Sun/Ultra Moon

7011: Elio - (NO HAIR VERSION)

702: Selene - Pokémon Sun/Moon

7022: Selene - (NO HAIR VERSION)

703: Hau - Pokémon Sun/Moon

704: Lillie - Pokémon Sun/Moon

705: Gladion - Pokémon Sun/Moon

750: Team Skull - Pokémon Sun/Moon

751: Aether Foundation - Pokémon Sun/Moon

~ ~ ~
Gen 8

801: Victor - Pokémon Sword/Shield

8011: Victor - (NO HAIR VERSION)

802: Gloria - Pokémon Sword/Shield

8022: Gloria - (NO HAIR VERSION)

803: Hop - Pokémon Sword/Shield

804: Marnie - Pokémon Sword/Shield

~ ~ ~
Gen 9

901: Nemona - Pokémon Scarlet/Violet

902: Penny - Pokémon Scarlet/Violet

950: Team Star - Pokémon Scarlet/Violet

~ ~ ~

If a hat looks like a mess of purple and black checkerboard textures, press F3+T to reload the resource pack! This should fix it.

~ ~ ~


Thanks for downloading! At the time of release, only certain versions/outfits for different trainers are included, but more variants may be added in the future! Check back for updates if a trainer or design you like is missing!